import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MutfakGUI extends JPanel {
    private JTable table;
    private JScrollPane scrollPane;
    private String[] columnNames = {"Yemek Adı", "Hazırlanma Süresi", "Hazırlandı"};
    private Object[][] data;

    public MutfakGUI(JFrame frame, RestoranYonetimi restoran, Menu menu, Masa masa) {
        // Mutfakta bulunan yemeklerin listesini al
        List<Siparis> yemekler = masa.getSiparisler();
        data = new Object[yemekler.size()][3];

        // Yemek verilerini tabloya ekle
        for (int i = 0; i < yemekler.size(); i++) {
            data[i][0] = yemekler.get(i).getUrun();
            data[i][1] = " sn";
            data[i][2] = "Evet";
        }

        // Paneli düzenle
        setLayout(new BorderLayout());

        // JTable ile verileri ekle
        table = new JTable(data, columnNames);
        scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Mutfak Bilgilerini Gösteren Buton
        JButton btnShowMutfakInfo = new JButton("Mutfak Bilgilerini Göster");
        add(btnShowMutfakInfo, BorderLayout.SOUTH);

        // Buton tıklama olayını ayarla
        btnShowMutfakInfo.addActionListener(e -> showMutfakInfo(yemekler));
    }

    private void showMutfakInfo(List<Siparis> yemekler) {
        // Yeni bir panel oluşturulur
        JPanel mutfakPanel = new JPanel(new BorderLayout());
        Object[][] yemekData = new Object[yemekler.size()][3];

        // Verileri güncelle
        for (int i = 0; i < yemekler.size(); i++) {
            yemekData[i][0] = yemekler.get(i).getUrun();
            yemekData[i][1] = " 10 sn";
            yemekData[i][2] = "Evet";
        }

        JTable mutfakTable = new JTable(yemekData, columnNames);
        JScrollPane mutfakScrollPane = new JScrollPane(mutfakTable);
        mutfakPanel.add(mutfakScrollPane, BorderLayout.CENTER);

        // Yeni pencereyi göster
        JDialog mutfakDialog = new JDialog((Frame) null, "Mutfak Bilgileri", true);
        mutfakDialog.setSize(400, 300);
        mutfakDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        mutfakDialog.add(mutfakPanel);
        mutfakDialog.setVisible(true);
    }
}
